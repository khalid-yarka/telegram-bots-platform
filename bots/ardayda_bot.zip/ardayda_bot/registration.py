import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from bots.ardayda_bot import database

# Load your school dictionary
from bots.ardayda_bot.text import form_four_schools_by_region  # make sure it exists

# Registration state in memory
registration_state = {}

# Constants
SCHOOLS_PER_PAGE = 5


def start_registration(bot, user_id):
    """Start registration flow"""
    registration_state[user_id] = {
        "step": "name",
        "data": {},
        "page": 0
    }
    bot.send_message(user_id, "👋 Welcome! Please enter your **full name**:")


def handle_message(bot, message):
    """Handle text messages during registration"""
    user_id = message.from_user.id
    state = registration_state.get(user_id)

    # If user is not in registration, ignore
    if not state:
        return False

    step = state["step"]
    text = message.text.strip()

    if step == "name":
        state["data"]["name"] = text
        state["step"] = "region"
        ask_region(bot, user_id)
        return True

    elif step == "region":
        # Validate region selection from buttons
        if text not in form_four_schools_by_region:
            bot.send_message(user_id, "❌ Please select a region using the buttons below.")
            ask_region(bot, user_id)
            return True
        state["data"]["region"] = text
        state["step"] = "school"
        state["page"] = 0
        ask_school(bot, user_id)
        return True

    elif step == "class":
        # Optional: validate class
        state["data"]["class"] = text
        finalize_registration(bot, user_id)
        return True

    return False  # Not handled


# ==================== ASK FUNCTIONS ====================

def ask_region(bot, user_id):
    kb = InlineKeyboardMarkup(row_width=2)
    for region in form_four_schools_by_region.keys():
        kb.add(InlineKeyboardButton(f"🏫 {region}", callback_data=f"reg_region|{region}"))
    bot.send_message(user_id, "Please select your region:", reply_markup=kb)


def ask_school(bot, user_id):
    """Ask school with pagination"""
    state = registration_state[user_id]
    region = state["data"]["region"]
    schools = form_four_schools_by_region[region]
    page = state["page"]
    start = page * SCHOOLS_PER_PAGE
    end = start + SCHOOLS_PER_PAGE
    kb = InlineKeyboardMarkup(row_width=1)

    for school in schools[start:end]:
        kb.add(InlineKeyboardButton(f"🏫 {school}", callback_data=f"reg_school|{school}"))

    # Pagination buttons
    buttons = []
    if start > 0:
        buttons.append(InlineKeyboardButton("⬅️ Prev", callback_data="school_prev"))
    if end < len(schools):
        buttons.append(InlineKeyboardButton("➡️ Next", callback_data="school_next"))
    if buttons:
        kb.add(*buttons)

    bot.send_message(user_id, "Please select your school:", reply_markup=kb)


# ==================== CALLBACK HANDLER ====================

def handle_callback(bot, call):
    user_id = call.from_user.id
    state = registration_state.get(user_id)
    if not state:
        return False

    data = call.data

    # ===== Region selection =====
    if data.startswith("reg_region|"):
        region = data.split("|")[1]
        state["data"]["region"] = region
        state["step"] = "school"
        state["page"] = 0
        ask_school(bot, user_id)
        bot.answer_callback_query(call.id)
        return True

    # ===== School selection =====
    elif data.startswith("reg_school|"):
        school = data.split("|")[1]
        state["data"]["school"] = school
        state["step"] = "class"
        bot.send_message(user_id, "✅ Great! Now enter your class (optional, e.g., F4, F3) or type 'skip':")
        bot.answer_callback_query(call.id)
        return True

    # ===== Pagination =====
    elif data == "school_next":
        state["page"] += 1
        ask_school(bot, user_id)
        bot.answer_callback_query(call.id)
        return True
    elif data == "school_prev":
        state["page"] -= 1
        ask_school(bot, user_id)
        bot.answer_callback_query(call.id)
        return True

    return False


# ==================== FINALIZE ====================

def finalize_registration(bot, user_id):
    state = registration_state[user_id]
    data = state["data"]

    # Optional: skip class
    user_class = data.get("class")
    if user_class and user_class.lower() == "skip":
        data["class"] = None

    # Save to database using your existing function
    database.update_user(
        user_id,
        name=data.get("name"),
        school=data.get("school"),
        class=data.get("class")
    )

    bot.send_message(user_id, "🎉 Registration complete! Here is your main menu:")
    from bots.ardayda_bot.buttons import Buttons  # your existing buttons
    bot.send_message(user_id, "Choose an option:", reply_markup=Buttons.MainMenu.keyboard())

    # Remove user from registration state
    registration_state.pop(user_id, None)